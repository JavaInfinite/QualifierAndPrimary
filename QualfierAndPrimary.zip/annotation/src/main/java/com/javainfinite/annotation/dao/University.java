package com.javainfinite.annotation.dao;

public interface University {

    public String display();
}
