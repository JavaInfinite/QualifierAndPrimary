package com.javainfinite.annotation.service;

import com.javainfinite.annotation.dao.University;
import org.springframework.stereotype.Service;

@Service("Alpha")
public class AlphaUniversity implements University {

    @Override
    public String display() {

        return "This is a message from Alpha University";
    }
}
